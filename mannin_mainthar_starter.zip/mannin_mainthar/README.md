# MANNIN MAINTHAR – Interactive starter website

This is a lightweight, mobile-first interactive starter for the MANNIN MAINTHAR agriculture platform.

## Run
Open `index.html` in a modern browser, or serve this folder with any static web server.

## Included
- Responsive homepage and navigation
- Tamil / English interface toggle with language saved in localStorage
- Marketplace search and category/location filters
- Farmer product listing form
- Demo registration/login and role-aware dashboard
- Seller contact and phone call action
- Crop photo preview and file validation
- Starter assistant with browser text-to-speech

## Important limitations
This is a frontend starter, not yet a production MERN deployment.
- Authentication is a local demo only. It stores demo credentials in browser localStorage; do not use real passwords.
- Listings are stored in the current browser only.
- Crop Doctor does not diagnose disease. A secure crop-analysis AI backend must be connected.
- The assistant uses a sample response. Connect a server-side AI provider for live answers.
- Admin moderation, MongoDB persistence, JWT security, Cloudinary uploads, and real-time voice AI still need backend implementation.

## Next production stage
Add an Express API, MongoDB/Mongoose models, bcrypt password hashing, JWT sessions, role-based authorization, validated image storage, AI provider integration and automated tests. Never put API keys in browser code.
